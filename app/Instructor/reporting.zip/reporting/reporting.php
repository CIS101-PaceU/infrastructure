<html>
<head>


</head>
<body>
<div style="margin-left:50%;padding:10px 16px;">
<table>
<tr><td style="padding:15px;">

 <a id='head-links' href='process.php'>Attendance</a></td></tr>
<tr><td style="padding:15px;"><a id='head-links' href='assignments.php'>Assignments</a>
</td></tr>
<tr><td style="padding:15px;">
<a id='head-links' href='cheating.php'>Cheating</a></tr></table>
</div>
</body>
</html>
